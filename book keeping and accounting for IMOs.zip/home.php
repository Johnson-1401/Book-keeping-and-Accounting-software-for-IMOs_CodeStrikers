<!DOCTYPE html>
<html>
<head>
	<title>index</title>
</head>
<body style="background-image: url('homes.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%;">
<table>
<tr>
	<th><h1 style="margin-left:60px;color: white;">Development of Women</style></h1></th>
	<th><button onclick="window.location.href='company.php';" style="width: 150px; height: 45px;border-radius: 30px;margin-left: 800px;background-color:red;border-color: red"><center><p>LOGIN</center></th>
</tr>
</table><hr>
<br>
<br>
	<center>
	<h1>" Women welfare"</h1>
	<h1>welcome to our women and child welfare system</h1>
	<button onclick="window.location.href='grouplog.php';" style="width: 250px; height: 45px;border-radius: 100px;background-color:Green ;border-color: green"><center><b style="color: white">GET START</center>
	</button>
</center>
</body>
</html>