<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body style="background-image: url('d1.jpeg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%">
<table>
	<tr>
		<th><h1 style="margin-left:90px">CODE STRIKERS...</style></h1></th>
	</tr>
</table>
<hr>
	<div style="margin-left: 290px">
	<h1>Please check your Gmail..</h1>
	<h2>Becouse many user request in your inbox</h2>
</div><br>
<center>
	<button onclick="window.location.href='https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin';" style="width: 220px; height: 75px;border-radius: 20px; background-color: red;border-color: red"><h1><center>Gmail</center></h1>
</center>
</body>
</html>