<!DOCTYPE html>
<html>
<head>
	<title>Gallery</title>
</head>
<body style="background-image: url('event.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%">
<h1 style="margin-left:90px">CODE STRIKERS...</h1><hr><br>
<center>
<h1 style="margin-left: 100px;font-family: timesnewroman"><b>"GALLERY"<b></h1>
</center>
<table>
<tr>
   <td><img style="width: 200px;height: 130px; margin-left: 270px;margin-bottom: 30px" src='h1.jpg'></td>
   <td><img style="width: 200px;height: 130px; margin-left: 100px;margin-bottom: 30px" src='h2.jpg'></td>
   <td><img style="width: 200px;height: 130px; margin-left: 100px;margin-bottom: 30px" src='h3.jpg'></td>
</tr>
<tr>
   <td><img style="width: 200px;height: 130px; margin-left: 270px;margin-bottom: 30px" src='h4.jpg'></td>
   <td><img style="width: 200px;height: 130px; margin-left: 100px;margin-bottom: 30px" src='h5.jpg'></td>
   <td><img style="width: 200px;height: 130px; margin-left: 100px;margin-bottom: 30px" src='h6.jpg'></td>
</tr>
<tr>
   <td><img style="width: 200px;height: 130px; margin-left: 270px;margin-bottom: 30px" src='h7.jpg'></td>
   <td><img style="width: 200px;height: 130px; margin-left: 100px;margin-bottom: 30px" src='h8.jpg'></td>
   <td><a href="#"><br><br><br><br><h3 style="margin-left: 100px"> See More ............</a>
</tr>
</table>
</body>
</html>
