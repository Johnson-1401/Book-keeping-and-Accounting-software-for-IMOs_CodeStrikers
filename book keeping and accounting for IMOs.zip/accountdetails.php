<!DOCTYPE html>
<html>
<head>
	<title>Account Details</title>
</head>
	<body style="background-image: url('d1.jpeg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%">
		<h1 style="margin-left:90px">CODE STRIKERS...</h1><hr><br>
		<table>
			<tr>
				<th><a href="monthly.php" style="font-size: 20px;text-decoration: none; margin-left: 450px;color: red">Monthly Details</a><br></th>
				<th><a href="savings.php" style="font-size: 20px;text-decoration: none;margin-left: 50px;color: red">Saving Details</a><br></th>
				<th><a href="loan.php" style="font-size: 20px;text-decoration: none;color: red; margin-left: 50px">Loan Details</a><br></th>
				<th><a href="public.php" style="font-size: 20px;text-decoration: none;color: red; margin-left:50px">Public Details</a><br></th>
				<th><a href="received.php" style="font-size: 20px;text-decoration: none; color: red;margin-left:50px">Received Amount</a><br></th>
			</tr>        
        </table>
        <a href="share.php" style="text-decoration:none;color: white;"><center><h2 style="background-color:blue">Share the amount to User</h2></center></a>
        <h3>if you share the amount to user, that details id show<a href="sharedetails.php"> learn more...</a></h3>
</body>
</html
