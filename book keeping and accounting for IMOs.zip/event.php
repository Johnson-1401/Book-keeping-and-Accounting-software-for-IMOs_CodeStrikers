<!DOCTYPE html>
<html>
<head>
  <title>Events</title>
</head>
<body style="background-image: url('event.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%">
<h1 style="margin-left:90px">CODE STRIKERS...</h1><hr><br>
<center>
<h1 style="font-family: timesnewroman"><b>"Events"<b></h1></center><br>
<table>
<tr>
  <td><img style="width: 200px;height: 130px; margin-left: 200px;" src='g1.jpg'></td>
  <td><img style="width: 200px;height: 130px; margin-left: 90px;" src='g2.jpg'></td>
  <td><img style="width: 200px;height: 130px; margin-left: 90px;" src='g3.jpg'></td>  
</tr>
<tr>
  <td><h3 style="width: 250px;height: 250px; margin-left: 200px;margin-bottom: 30px">Group Meeting.........<br> Arranged and Meeting Date is Apirl 1st Week</h3></td>
  <td><h3 style="width: 250px;height: 250px; margin-left: 90px;margin-bottom: 30px">Group Meeting......... <br>Arranged and Meeting Date is Apirl 2st Week</h3></td>
  <td><h3 style="width: 250px;height: 250px; margin-left: 90px;margin-bottom: 30px">Group Meeting......... <br>Arranged and Meeting Date is Apirl 3st Week</h3></td>  
</tr>
</table>
</body>
</html>
    