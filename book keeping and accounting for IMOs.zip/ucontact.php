<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body style="background-image: url('h2.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%">
<table>
	<tr>
		<th><h1 style="margin-left:90px">CODE STRIKERS...</style></h1></th>
	</tr>
</table>
<hr>
<div style="margin-left: 300px">
	<h2>Admin Gmail ID : johnson@gmail.com</h2>
	<h2>Admin Phone No : 9360655122</h2>
	<h2>Admin Twitter ID : @johnson</h2>
</div>
	<div style="margin-left: 100px">
	<p>If you any doubt and any loan request you will asked to me</p>

	<button onclick="window.location.href='https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin';" style="width: 120px; height: 45px;border-radius: 10px; background-color: red;border-color: red"><center>Gmail</center>
</div>
</body>
</html>